const Auction = require('../models/Auction');
const Bid = require('../models/Bid');
const AuctionParticipant = require('../models/AuctionParticipant');
const AuctionDocument = require('../models/AuctionDocument');
const User = require('../models/User');
const { sendSMS } = require('../utils/smsService');
const db = require('../db');

exports.createAuction = async (req, res) => {
  try {
    const {
      title,
      description,
      auction_date,
      start_time,
      duration,
      currency,
      base_price,
      decremental_value,
      pre_bid_allowed = true,
      participants,
      send_invitations = true
    } = req.body;

    if (!title || !auction_date || !start_time || !duration || !base_price) {
      return res.status(400).json({
        success: false,
        message: 'Title, date, start time, duration, and base price are required'
      });
    }

    const created_by = req.user.userId;

    const auctionId = await Auction.create({
      title,
      description,
      auction_date,
      start_time,
      duration: parseInt(duration) * 60,
      currency: currency || 'INR',
      base_price: parseFloat(base_price),
      decremental_value: decremental_value ? parseFloat(decremental_value) : 0,
      pre_bid_allowed: pre_bid_allowed === 'true' || pre_bid_allowed === true,
      created_by
    });

    let participantList = [];
    let smsCount = 0;
    let smsFailures = [];
    
    if (participants) {
      participantList = Array.isArray(participants) ? participants : [participants];
      participantList = [...new Set(participantList)].filter(p => p);

      if (participantList.length > 0) {
        const participantData = participantList.map(phone => ({
          user_id: null,
          phone_number: phone
        }));

        await AuctionParticipant.addMultiple(auctionId, participantData);

        if (send_invitations === 'true' || send_invitations === true) {
          try {
            const auction = await Auction.findById(auctionId);
            
            // Create a shorter, SMS-friendly message
            const auctionDate = new Date(auction.auction_date).toLocaleDateString('en-IN');
            const message = `Join "${auction.title}" auction on ${auctionDate} at ${auction.start_time}. Website: https://yourauctionapp.com`;

            console.log(`📨 Preparing to send ${participantList.length} invitation(s)`);

            // Send SMS to each participant with better error handling
            for (const participant of participantList) {
              try {
                console.log(`📤 Sending invitation to: ${participant}`);
                
                // ✅ Use transactional SMS for now (set isPromotional = false)
                await sendSMS(participant, message, true); // true = promotional
                
                console.log(`✅ Successfully sent to: ${participant}`);
                smsCount++;
              } catch (smsError) {
                console.error(`❌ Failed to send to ${participant}:`, smsError.message);
                smsFailures.push({
                  participant: participant,
                  error: smsError.message
                });
                
                // Continue with other participants even if one fails
                continue;
              }
              
              // Add a small delay between messages
              await new Promise(resolve => setTimeout(resolve, 500));
            }

            // Log summary
            if (smsFailures.length > 0) {
              console.warn(`⚠️ ${smsFailures.length} SMS failed to send:`);
              smsFailures.forEach(failure => {
                console.warn(`   - ${failure.participant}: ${failure.error}`);
              });
            }

          } catch (smsError) {
            console.error('❌ Failed to process invitation SMS:', smsError);
            // Continue even if SMS processing fails
          }
        }
      }
    }

    if (req.files && req.files.length > 0) {
      for (const file of req.files) {
        await AuctionDocument.add({
          auction_id: auctionId,
          file_name: file.originalname,
          file_path: file.path,
          file_type: file.mimetype
        });
      }
    }

    const auction = await Auction.findById(auctionId);

    // Prepare response message
    let responseMessage = `Auction created successfully with ${participantList.length} participant(s)`;
    if (smsCount > 0) {
      responseMessage += ` and ${smsCount} invitation(s) sent`;
    }
    if (smsFailures.length > 0) {
      responseMessage += `, ${smsFailures.length} invitation(s) failed`;
    }

    res.status(201).json({
      success: true,
      message: responseMessage,
      auction,
      smsResults: {
        totalParticipants: participantList.length,
        successfulSMS: smsCount,
        failedSMS: smsFailures.length,
        failures: smsFailures
      }
    });

  } catch (error) {
    console.error('❌ Create auction error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.getUserAuctions = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { status } = req.query;

    const auctions = await Auction.findByUser(userId, status);

    res.json({
      success: true,
      auctions,
      count: auctions.length
    });

  } catch (error) {
    console.error('❌ Get user auctions error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.getAuctionDetails = async (req, res) => {
  try {
    const { id } = req.params;

    const auction = await Auction.findById(id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    const participants = await AuctionParticipant.findByAuction(id);
    const documents = await AuctionDocument.findByAuction(id);
    const bids = await Bid.findByAuction(id);

    res.json({
      success: true,
      auction: {
        ...auction,
        participants,
        documents,
        bids
      }
    });

  } catch (error) {
    console.error('❌ Get auction details error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.getLiveAuctions = async (req, res) => {
  try {
    const auctions = await Auction.findLive();

    res.json({
      success: true,
      auctions,
      count: auctions.length
    });

  } catch (error) {
    console.error('❌ Get live auctions error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.placeBid = async (req, res) => {
  try {
    const { auction_id, amount } = req.body;
    const user_id = req.user.userId;

    if (!auction_id || !amount) {
      return res.status(400).json({
        success: false,
        message: 'Auction ID and bid amount are required'
      });
    }

    const auction = await Auction.findById(auction_id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    if (auction.status !== 'live') {
      return res.status(400).json({
        success: false,
        message: 'Auction is not live'
      });
    }

    const bidAmount = parseFloat(amount);
    if (isNaN(bidAmount) || bidAmount <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Invalid bid amount'
      });
    }

    if (auction.decremental_value > 0 && bidAmount >= auction.current_price) {
      return res.status(400).json({
        success: false,
        message: `Bid must be lower than current price (${auction.current_price})`
      });
    }

    if (auction.decremental_value === 0 && bidAmount <= auction.current_price) {
      return res.status(400).json({
        success: false,
        message: `Bid must be higher than current price (${auction.current_price})`
      });
    }

    const bidId = await Bid.create({
      auction_id,
      user_id,
      amount: bidAmount
    });

    await Auction.updateCurrentPrice(auction_id, bidAmount);
    await Bid.setWinningBid(bidId);

    const updatedAuction = await Auction.findById(auction_id);
    const bids = await Bid.findByAuction(auction_id);

    res.json({
      success: true,
      message: 'Bid placed successfully',
      bid: {
        id: bidId,
        auction_id,
        user_id,
        amount: bidAmount,
        bid_time: new Date()
      },
      auction: updatedAuction,
      bids
    });

  } catch (error) {
    console.error('❌ Place bid error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.closeAuction = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.userId;

    const auction = await Auction.findById(id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    if (auction.created_by !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Only auction creator can close the auction'
      });
    }

    const winningBid = await Bid.findWinningBid(id);
    const winnerId = winningBid ? winningBid.user_id : null;

    await Auction.updateStatus(id, 'completed', winnerId);
    const updatedAuction = await Auction.findById(id);

    res.json({
      success: true,
      message: 'Auction closed successfully',
      auction: updatedAuction,
      winner: winningBid
    });

  } catch (error) {
    console.error('❌ Close auction error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.addParticipants = async (req, res) => {
  try {
    const { auction_id, participants, send_invitations } = req.body;
    const userId = req.user.userId;

    if (!auction_id || !participants) {
      return res.status(400).json({
        success: false,
        message: 'Auction ID and participants are required'
      });
    }

    const auction = await Auction.findById(auction_id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    if (auction.created_by !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Only auction creator can add participants'
      });
    }

    let participantList = Array.isArray(participants) ? participants : [participants];
    participantList = [...new Set(participantList)].filter(p => p);
    
    if (participantList.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid participants provided'
      });
    }

    const participantData = participantList.map(phone => ({
      user_id: null,
      phone_number: phone
    }));

    const addedCount = await AuctionParticipant.addMultiple(auction_id, participantData);
    let smsCount = 0;
    let smsFailures = [];

    if (send_invitations === 'true' || send_invitations === true) {
      try {
        const auction = await Auction.findById(auction_id);
        const auctionDate = new Date(auction.auction_date).toLocaleDateString('en-IN');
        const message = `Please submit Pre Bid on Auction Website to join Auction "${auction.title}" on ${auctionDate} at ${auction.start_time}. Website: https://yourauctionapp.com`;

        for (const participant of participantList) {
          try {
            await sendSMS(participant, message, true); // true = promotional
            smsCount++;
          } catch (smsError) {
            console.error(`❌ Failed to send to ${participant}:`, smsError.message);
            smsFailures.push({
              participant: participant,
              error: smsError.message
            });
          }
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      } catch (smsError) {
        console.error('❌ Failed to send invitation SMS:', smsError);
      }
    }

    res.json({
      success: true,
      message: `Added ${addedCount} participant(s)${smsCount > 0 ? ` and sent ${smsCount} invitation(s)` : ''}${smsFailures.length > 0 ? `, ${smsFailures.length} failed` : ''}`,
      participants: participantList,
      smsResults: {
        successfulSMS: smsCount,
        failedSMS: smsFailures.length,
        failures: smsFailures
      }
    });

  } catch (error) {
    console.error('❌ Add participants error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.getParticipants = async (req, res) => {
  try {
    const { auction_id } = req.params;
    const userId = req.user.userId;

    const auction = await Auction.findById(auction_id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    if (auction.created_by !== userId) {
      return res.status(403).json({
        success: false,
        message: 'Only auction creator can view participants'
      });
    }

    const participants = await AuctionParticipant.findByAuction(auction_id);

    res.json({
      success: true,
      participants,
      count: participants.length
    });

  } catch (error) {
    console.error('❌ Get participants error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};

exports.joinAuction = async (req, res) => {
  try {
    const { auction_id, phone_number } = req.body;

    if (!auction_id || !phone_number) {
      return res.status(400).json({
        success: false,
        message: 'Auction ID and phone number are required'
      });
    }

    const auction = await Auction.findById(auction_id);
    if (!auction) {
      return res.status(404).json({
        success: false,
        message: 'Auction not found'
      });
    }

    const isParticipant = await AuctionParticipant.isParticipant(auction_id, phone_number);
    if (!isParticipant) {
      return res.status(403).json({
        success: false,
        message: 'You are not invited to this auction'
      });
    }

    await AuctionParticipant.updateStatus(auction_id, phone_number, 'joined');

    res.json({
      success: true,
      message: 'Joined auction successfully'
    });

  } catch (error) {
    console.error('❌ Join auction error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error',
      error: error.message
    });
  }
};