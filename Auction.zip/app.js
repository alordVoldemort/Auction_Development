const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const http = require('http');
const { Server } = require('socket.io');
require('dotenv').config();

const authRoutes = require('./routes/user-auth-routes');
const auctionRoutes = require('./routes/auction'); 

const app = express();
const server = http.createServer(app); // Use HTTP server
const io = new Server(server, {
  cors: {
    origin: "*",  // You can restrict this to frontend domain later
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/auction', auctionRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ success: true, message: 'Server is running' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Something went wrong!' });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Route not found' });
});

// WebSocket handling
io.on('connection', (socket) => {
  console.log('🔵 User connected:', socket.id);

  // Example: Listen for bids
  socket.on('placeBid', (data) => {
    console.log('📢 New Bid:', data);
    // Broadcast to all connected clients
    io.emit('newBid', data);
  });

  socket.on('disconnect', () => {
    console.log('🔴 User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Server is running on port ${PORT}`);
});
