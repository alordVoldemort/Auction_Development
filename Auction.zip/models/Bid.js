const db = require('../db');

class Bid {
  static async create(bidData) {
    const { auction_id, user_id, amount } = bidData;
    
    const [result] = await db.query(
      'INSERT INTO bids (auction_id, user_id, amount) VALUES (?, ?, ?)',
      [auction_id, user_id, amount]
    );
    
    return result.insertId;
  }

  static async findByAuction(auctionId) {
    const [bids] = await db.query(
      `SELECT b.*, u.company_name, u.person_name 
       FROM bids b 
       JOIN users u ON b.user_id = u.id 
       WHERE b.auction_id = ? 
       ORDER BY b.bid_time DESC`,
      [auctionId]
    );
    return bids;
  }

  static async findWinningBid(auctionId) {
    const [bids] = await db.query(
      `SELECT b.*, u.company_name, u.person_name 
       FROM bids b 
       JOIN users u ON b.user_id = u.id 
       WHERE b.auction_id = ? AND b.is_winning = TRUE`,
      [auctionId]
    );
    return bids[0];
  }

  static async setWinningBid(bidId) {
    const [bid] = await db.query('SELECT auction_id FROM bids WHERE id = ?', [bidId]);
    if (bid.length === 0) return 0;
    
    await db.query(
      'UPDATE bids SET is_winning = FALSE WHERE auction_id = ?',
      [bid[0].auction_id]
    );
    
    const [result] = await db.query(
      'UPDATE bids SET is_winning = TRUE WHERE id = ?',
      [bidId]
    );
    
    return result.affectedRows;
  }

  static async findByUser(userId) {
    const [bids] = await db.query(
      `SELECT b.*, a.title as auction_title, a.status as auction_status 
       FROM bids b 
       JOIN auctions a ON b.auction_id = a.id 
       WHERE b.user_id = ? 
       ORDER BY b.bid_time DESC`,
      [userId]
    );
    return bids;
  }
}

module.exports = Bid;