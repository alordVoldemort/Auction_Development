const db = require('../db');

class Auction {
  static async create(auctionData) {
    const {
      title,
      description,
      auction_date,
      start_time,
      duration,
      currency,
      base_price,
      decremental_value,
      pre_bid_allowed,
      created_by
    } = auctionData;

    const [result] = await db.query(
      `INSERT INTO auctions 
       (title, description, auction_date, start_time, duration, currency, base_price, current_price, decremental_value, pre_bid_allowed, created_by) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [title, description, auction_date, start_time, duration, currency, base_price, base_price, decremental_value, pre_bid_allowed, created_by]
    );

    return result.insertId;
  }

  static async findById(id) {
    const [auctions] = await db.query(
      `SELECT a.*, u.company_name as creator_company, u.person_name as creator_name 
       FROM auctions a 
       JOIN users u ON a.created_by = u.id 
       WHERE a.id = ?`,
      [id]
    );
    return auctions[0];
  }

  static async findByUser(userId, status = null) {
    let query = `
      SELECT a.*, u.company_name as creator_company, u.person_name as creator_name,
             (SELECT COUNT(*) FROM bids WHERE auction_id = a.id) as bid_count,
             (SELECT COUNT(*) FROM auction_participants WHERE auction_id = a.id) as participant_count
      FROM auctions a 
      JOIN users u ON a.created_by = u.id 
      WHERE a.created_by = ?
    `;
    
    const params = [userId];
    
    if (status) {
      query += ' AND a.status = ?';
      params.push(status);
    }
    
    query += ' ORDER BY a.created_at DESC';
    
    const [auctions] = await db.query(query, params);
    return auctions;
  }

  static async findLive() {
    const [auctions] = await db.query(
      `SELECT a.*, u.company_name as creator_company, u.person_name as creator_name,
             (SELECT COUNT(*) FROM bids WHERE auction_id = a.id) as bid_count
       FROM auctions a 
       JOIN users u ON a.created_by = u.id 
       WHERE a.status = 'live' 
       ORDER BY a.auction_date, a.start_time`
    );
    return auctions;
  }

  static async updateStatus(id, status, winnerId = null) {
    let query = 'UPDATE auctions SET status = ?, updated_at = NOW() WHERE id = ?';
    const params = [status, id];
    
    if (winnerId) {
      query = 'UPDATE auctions SET status = ?, winner_id = ?, updated_at = NOW() WHERE id = ?';
      params.splice(1, 0, winnerId);
    }
    
    const [result] = await db.query(query, params);
    return result.affectedRows;
  }

  static async updateCurrentPrice(id, price) {
    const [result] = await db.query(
      'UPDATE auctions SET current_price = ?, updated_at = NOW() WHERE id = ?',
      [price, id]
    );
    return result.affectedRows;
  }
}

module.exports = Auction;